#include <iostream>
using namespace std;
#include <string>

#include "Session.h"

//constructor
Session::Session(string n,int t){
    name=n;
    time=t;
    types= new Frequency*[4];
    types[0]=new Frequency("9-11 Hz");
    types[1]=new Frequency("18-22 Hz");
    types[2]=new Frequency("6-8 Hz");
    types[3]=new Frequency("0.5-3 Hz");

}

//destructor
Session::~Session(){
    cout<<" "<<endl;
}

//getter & setter
void Session::setTime(int n){time=n;}
int Session::getTime(){return time;}
string Session::getName(){return name;}


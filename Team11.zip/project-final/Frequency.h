#ifndef FREQUENCY_H
#define FREQUENCY_H
#include <iostream>
#include <string>

using namespace std;

class Frequency{   
    public:
        //constructor
        Frequency(string);
        //destructor
        ~Frequency();

        //getter
        string getName();

    private:
        string name;

        
};

#endif

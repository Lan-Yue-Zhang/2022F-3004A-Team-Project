#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <iostream>
#include <QMainWindow>
#include <QTimer>
#include"Session.h"
#include"Power.h"
#include"Recording.h"
#include<string>
#include <QDateTime>
#include "record.h"
#include <QThread>
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Power *power1;
    Session** Session_group;

    Recording* db;
    //yuren
    QTimer *timer;

    void connect_ear();
    void disconnect_ear();
    void up();
    void down();
    void light_blink();

    //yuren
    void checkTime();
    void power();
    void turn_on();
    void powerOn();
    void turn_off();
    void change_power();
    void actual_off();
    void push_8_w();
    void push_7_r(), push_7_w();
    void push_6_r(), push_6_w();
    void push_5_r(), push_5_w();
    void push_4_r(), push_4_w();
    void push_3_r(), push_3_w();
    void push_2_r(), push_2_w();
    void push_1_r(), push_1_w();

    void record();

    void selected_button();
    void stop();
    void low_power();

    //wenyue Yang
    void choose_session();
    void choose_session2();
    void choose_type();
    void choose_type2();
    void save();
    void session_color();
    void sessiontype_color();
    void updateRecord();
    void updateUerdesign();
    void therapy();
    void charge();
private slots:
    void updateTime();

private:
    Ui::MainWindow *ui;
    string current_state;
    string current_selected;
    //prof
    int current_user=1;
    int current_session=0;
    int current_type=0;
    int current_intensity=1;
    bool is_connectEar=false;
    //
    Session* session;
    QTime *design_time;
    QTimer* therapy_timer;
    //helper
    int userset=0;
    int record_select=0;
    Record* current_record=new Record("1",0,0,0,0);
};
#endif // MAINWINDOW_H

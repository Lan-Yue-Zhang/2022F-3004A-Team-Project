#ifndef RECORD_H
#define RECORD_H
#include <iostream>
#include <string>

using namespace std;

class Record{   
    public:
        //constructor
        Record(string,int,int,int,int);
        //destructor
        ~Record();

        //getter & setter
        int getSession();
        int getType();
        int getintensisty();
        int getuid();
        string getTime();
        void setSession(int);
        void setType(int);
        void setintensisty(int);

    private:
        string time;
        int session;
        int type;
        int intensisty;
        int uid;



        
};

#endif

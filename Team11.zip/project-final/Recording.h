#ifndef RECORDING_H
#define RECORDING_H
using namespace std;
#include <QString>
#include <QSqlDatabase>
#include <QDateTime>
#include <QDebug>
#include <QSqlQuery>
#include <QList>
#include <QApplication>
#include <iostream>
#include <string>
#include "record.h"
class Recording {

public:
    const QString DATE_FORMAT = "yyyy-MM-dd hh:mm";
    static const QString DATABASE_PATH;

    Recording();
    void getRecordings(int,Record**);
    int* getProfile(int);
    void addProfile(int,int,int,int);
    void addRecord(int,int,int,int,const QDateTime&);
    //helper
    int num=0;
    int num_user1=0;
    int num_user2=0;
    int num_total=0;
    void updatenum(int id);
private:
    QSqlDatabase db;
    bool Init();

};

#endif


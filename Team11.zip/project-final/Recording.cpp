#include "Recording.h"
using namespace std;
#include <iostream>

//Connecting to the Database
const QString Recording::DATABASE_PATH = "/database/teamworkDb.db";
Recording::Recording() {
    db= QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("teamworkDb.db");
    if( !db.open()){
        throw "db.open failed.";
    }
    if( !Init()){
        throw "Error:can  not be initialized";
    }
}

//Initialization
bool Recording::Init() {
    db.transaction();
    QSqlQuery query;
    query.exec("drop table IF  EXISTS profiles");
    query.exec("drop table IF  EXISTS record");
    query.exec("CREATE TABLE IF NOT EXISTS  profiles(uid int primary key, session int, type int,intensity int)");
    query.exec("CREATE TABLE IF NOT EXISTS  record(id int primary key,uid int, session int,type int,intensity int,time TEXT NOT NULL)");
    //for test
    query.exec("INSERT OR REPLACE into profiles values(1, 0 ,0,1)");
    query.exec("INSERT OR REPLACE into profiles values(2, 0,0,1)");

    return db.commit();
}

//Get custom Settings based on the user id
int* Recording::getProfile(int id){

    db.transaction();
    QSqlQuery query;
    query.prepare("SELECT * FROM profiles WHERE uid=:uid");
    query.bindValue(":uid", id);
    query.exec();
    int* profile;
    profile=new int[4];
    while (query.next()){
        profile[0]=query.value(0).toString().toInt();
        profile[1]=query.value(1).toString().toInt();
        profile[2]=query.value(2).toString().toInt();
        profile[3]=query.value(3).toString().toInt();
    }
    if (!db.commit()) {
        throw "Error: Query failed to execute";
    }
    return profile;

}


//Get the record based on the user id
void Recording::getRecordings(int id,Record** r) {
    db.transaction();
    QSqlQuery query;
    query.prepare("SELECT * FROM record WHERE uid=:uid");
    query.bindValue(":uid", id);
    query.exec();
    int n=0;
    while (query.next()) {
        r[n]=new Record(query.value(5).toString().toStdString(),query.value(3).toString().toInt(),query.value(1).toString().toInt(),query.value(2).toString().toInt(),query.value(4).toString().toInt());
        n++;
    }
}

//Add a custom
void Recording::addProfile(int id,int s,int y,int i){
    db.transaction();
    QSqlQuery query;
    query.prepare("REPLACE INTO profiles(uid, session, type,intensity) VALUES (:uid, :session, :type,:intensity);");
    query.bindValue(":uid", id);
    query.bindValue(":session", s);
    query.bindValue(":type", y);
    query.bindValue(":intensity", i);
    query.exec();
    if (!db.commit()) {
        throw "Error: Query failed to execute";
    }
}

//Add a record
void Recording::addRecord(int id,int s,int y,int i,const QDateTime& t){
    db.transaction();
    QSqlQuery query;
    query.prepare("INSERT or replace into record(id, uid, session, type,intensity,time) VALUES (:id, :uid, :session, :type,:intensity,:time);");
    query.bindValue(":id", this->num_total);
    query.bindValue(":uid", id);
    query.bindValue(":session", s);
    query.bindValue(":type", y);
    query.bindValue(":intensity", i);
    query.bindValue(":time", t.toString(DATE_FORMAT));
    query.exec();
    if (!db.commit()) {
        throw "Error: Query failed to execute";
    }
    if(id==1){
        num_user1++;
    }else{
        num_user2++;
    }
    num++;
    num_total++;
    cout<<"The Record are saved successfully"<<endl;
}

//helper
void Recording::updatenum(int id) {
    if(id==1){
        num=num_user1;
    }else{
        num=num_user2;
    }

}

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Recording.h"
#include "Session.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    power1 = new Power();
    Session_group= new Session*[3];
    Session_group[0]=new Session("20 min",20);
    Session_group[1]=new Session("45 min",45);
    Session_group[2]=new Session("user design",0);
    //need change!!!!!!
    session=Session_group[current_session];

    db = new Recording();
    current_session=db->getProfile(current_user)[1];
    current_type=db->getProfile(current_user)[2];
    current_intensity=db->getProfile(current_user)[3];
    //yuan
    connect(ui->pushButton_15, &QPushButton::clicked,this,&MainWindow::connect_ear);
    connect(ui->pushButton_14, &QPushButton::clicked,this,&MainWindow::disconnect_ear);
    connect(ui->pushButton_1, &QPushButton::clicked,this,&MainWindow::selected_button);
    //wenyueyang
    connect(ui->pushButton_16, &QPushButton::clicked,this,&MainWindow::record);
    connect(ui->pushButton_13, &QPushButton::clicked,this,&MainWindow::save);

    //yuren
    connect(ui->toolButton, &QPushButton::pressed,this, &MainWindow::turn_on);
    timer = new QTimer(this);
    connect(ui->up, &QPushButton::pressed, this, &MainWindow::up);
    connect(ui->down, &QPushButton::pressed, this, &MainWindow::down);

//    current_state = "customize";
    current_selected = "1";
    design_time = new QTime(0,5,0);
    current_state = "close";
    connect(timer,SIGNAL(timeout()), this, SLOT(updateTime()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updateTime() {
  QTime newTime = design_time->addSecs(-1);
  design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
  ui->textBrowser->clear();
  ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
  if(design_time->second() == 0){
      timer->stop();
  }

}

//yuan
void MainWindow::connect_ear(){
    if(current_state=="open"){
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }
    if(current_state=="disconnect"){
        current_state="in_session";
        therapy();
        ui->lineEdit->setText("session is running now!");
        therapy_timer->start(Session_group[current_session]->getTime()*1000);
    }
}
//yuan
void MainWindow::disconnect_ear(){
    if(current_state=="in_session"){
         stop();
         ui->lineEdit->setText("The session is not ending, please ending the session first!");
         current_state="disconnect";
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }
}
void MainWindow::up(){
    //wenyueyang change
    if(current_state=="open"||current_state=="choose"){
        current_state="choose";
        ui->pushButton_20->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
        session_color();
        choose_session();
    }else if(current_state=="choose type"){
        ui->pushButton_4->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        sessiontype_color();
        choose_type();
    }else if(current_state=="userd"){
        userset+=5;
        updateUerdesign();
    }else if(current_state=="record"){
        if(record_select!=0){
            record_select--;
            record();
        }else{
            record_select=db->num-1;
            record();
        }
    }



    //

    int temp_current = stoi(current_selected);
   if (current_state == "in_session") {

       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = ui->centralwidget->findChild<QLabel*>(buttonName);
       tempPushButton->setStyleSheet(" ");
       if (temp_current < 8){
           temp_current += 1;
       }
       else {
           temp_current = 1;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
       ui->textBrowser->clear();
       ui->textBrowser->insertPlainText(QString::fromStdString("intensity:" + current_selected));
   } else if (current_state=="userd") {
 //       int currentTimerCount = 0;
 //       currentTimerCount += 30;
 //       QTime newTime(0,currentTimerCount/60,currentTimerCount%60);
 //       timeString = newTime->toString("mm:ss");
 //       scene->addText(timeString);


 //       QTime newTime = Time->addSecs(60*currentTimerCount);
 //       Time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
 //       ui->countdown->setPlainText(Time->toString("mm:ss"));
       QTime newTime = design_time->addSecs(60*5);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
//       string str = design_time->toString("mm:ss").toStdString();
//       qInfo(design_time->toString("mm:ss").toLatin1());

       }
   current_selected = to_string(temp_current);
   current_intensity = stoi(current_selected);

     }

 //    //LANYUE
 void MainWindow:: down(){
    //wenyueyang change
     if(current_state=="open"||current_state=="choose"){
         ui->pushButton_20->setStyleSheet("background-color:rgb(255,255,255)");
         ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
         current_state="choose";
         session_color();
         choose_session2();
     }else if(current_state=="choose type"){
         ui->pushButton_4->setStyleSheet("background-color:rgb(255,255,255)");
         ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
         sessiontype_color();
         choose_type2();
     }else if(current_state=="userd"){
         if(userset>5){
             userset=userset-5;
             updateUerdesign();
         }else{
             userset=0;
             updateUerdesign();
         }
     }else if(current_state=="record"){
         if(record_select!=db->num-1){
             record_select++;
             record();
         }else{
             record_select=0;
             record();
         }
     }

     //



    int temp_current = stoi(current_selected);
   if (current_state == "in_session") {
       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = findChild<QLabel*>(buttonName);

           tempPushButton->setStyleSheet(" ");

       if (temp_current > 1){
           temp_current -= 1;
       }
       else {
           temp_current = 8;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
       ui->textBrowser->clear();
       ui->textBrowser->insertPlainText(QString::fromStdString("intensity:" + current_selected));
   } else if (current_state=="userd") {
 //       int currentTimerCount = 0;
 //       currentTimerCount += 30;
 //       QTime newTime(0,currentTimerCount/60,currentTimerCount%60);
 //       timeString = newTime->toString("mm:ss");
 //       scene->addText(timeString);


 //       QTime newTime = Time->addSecs(60*currentTimerCount);
 //       Time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
 //       ui->countdown->setPlainText(Time->toString("mm:ss"));
       QTime newTime = design_time->addSecs(-60*5);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
//       string str = design_time->toString("mm:ss").toStdString();
       ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
//       qInfo(design_time->toString("mm:ss").toLatin1());
       }
   current_selected = to_string(temp_current);
   current_intensity = stoi(current_selected);
   }
//yuren
void MainWindow::power(){
    if(current_state=="close"){
        powerOn();
    }else if(current_state=="open"){
        turn_off();
    }else if(current_state==session->getName()){
        //change session group
    }
}
void MainWindow::turn_on(){ //when press power button call this
    if(current_state=="close"){
        QTimer::singleShot(2000, this, &MainWindow::checkTime); //after 2 seconds call checkTime()

    //wenyueYang change
    }else if(current_state=="choose type"){
        current_state="choose";
        current_type=0;
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
    }else if(current_state=="choose"){
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        current_state="open";
    }else if(current_state=="userd"){
       current_state="choose";
       userset=0;
       ui->textBrowser->clear();
    }else if(current_state=="record"){
        current_state="open";
        record_select=0;
        ui->textBrowser->clear();
    }
}

void MainWindow::checkTime(){ //after 2 seconds, button still being pressed
    if (ui->toolButton->isDown()) { //still in pressed position
        ui->checkBox->setCheckState(Qt::Checked);
        powerOn(); //turn on
    }
}

void MainWindow::powerOn(){
    ui->progressBar->setValue(100);     //set power to 100%
    //what else???
    current_state="open";
}
void MainWindow::turn_off(){
    if (current_state == "in_session"){
        //Soft off
        qInfo("Current status: in_session; turning off; soft off");
        if (current_intensity == 8){
            ui->push_7->setStyleSheet("background-color: rgb(250,175,175)");
            QThread::sleep(1);
            ui->push_7->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_6->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_6->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_5->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_5->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_4->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_4->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_3->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_3->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_2->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 7){
            ui->push_7->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_6->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_6->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_5->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_5->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_4->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_4->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_3->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_3->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_2->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 6){
            ui->push_6->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_5->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_5->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_4->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_4->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_3->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_3->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_2->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 5){
            ui->push_5->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_4->setStyleSheet("background-color: yellow");
            QThread::sleep(1);
            ui->push_4->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_3->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_3->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_2->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 4){
            ui->push_4->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_3->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_3->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_2->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 3){
            ui->push_3->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_2->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 2){
            ui->push_2->setStyleSheet("background-color: rgb(255,255,255)");
            ui->push_1->setStyleSheet("background-color: rgb(138,226,52)");
            QThread::sleep(1);
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        } else if (current_intensity == 1){
            ui->push_1->setStyleSheet("background-color: rgb(255,255,255)");
        }
    } else { // current state not in_session, direct turn off
        //press and hold
        qInfo("Current status: not in_session; turning off");
        QTimer::singleShot(2000, this, &MainWindow::actual_off);
    }
    //Change time color to black


}
void MainWindow::actual_off(){
    qInfo("test1");
    if (ui->toolButton->isDown()) { //still in pressed position
        qInfo("test2");
        ui->checkBox->setChecked(false);
    }
}
//yuren 12/5
//yuren
void MainWindow::change_power(){
    if (current_state == ""){ //doing nothing
        //battery bar does not change
    } else if (current_state == ""){ //doing work
        session->getTime(); //length of therapy
        //Intensity.getlevel(); //intensity ??? use what object ???
        //connections to skin ???
    }
}


//yuan
void MainWindow::stop(){
    if(current_state=="open"){
       turn_off();
    }
    else{
      ui->lineEdit->setText("Session has benn Stopped!");
    }
}
//yuan
void MainWindow::low_power(){
    if(current_state=="open" && power1->check()==true){
        ui->progressBar->setValue(5);
        ui->progressBar->setStyleSheet("background-color:red");
        ui->lineEdit->setText("Low Power now, Please charge new Battery!");
    }
    if(current_state=="open" && current_state=="in_session"){
        stop();
        change_power();
        ui->lineEdit->setText("session is running now! Turn off session first!");
    }    //display 2 bars and blink
    //check current state ="session" warning, replaced battery
}

void MainWindow::selected_button(){
    //yuan
    if(current_state=="choose"&&current_state!="choose type"){
      ui->pushButton_1->setStyleSheet("background-color:yellow");
     }else{
        ui->pushButton_1->setStyleSheet("background-color: rgb(255,255,255)");
     }
    if(current_state!="choose"&&current_state=="choose type"){
            ui->pushButton_1->setStyleSheet("background-color:yellow");
    }else{
     // if(current_state!="open"||current_state!="choose"||current_state!="choose type"){
         ui->pushButton_1->setStyleSheet("background-color: rgb(255,255,255)");
     }


//wenyueyang
    if(current_state=="choose"){
        cout<<"choose session:"<<current_session+1<<endl;
        if(current_session!=2){
            current_state="choose type";
            sessiontype_color();
        }else{
            current_state="userd";
            updateUerdesign();
        }
    }else if(current_state=="choose type"){
        ui->textBrowser->clear();
        cout<<"choose session:"<<current_session+1<<endl;
        cout<<"choose type:"<<current_type+1<<endl;
        cout<<"session will start in 5 secounds....."<<endl;
        updateRecord();
        current_state="in_session";
    }else if(current_state=="userd"){
        current_state="choose type";
        ui->textBrowser->clear();
        ui->textBrowser->setTextColor( QColor( "red" ) );
        ui->textBrowser->insertPlainText("The setting is successful! your session time is:");
        Session_group[2]->setTime(userset);
        ui->textBrowser->insertPlainText(QString::fromStdString(to_string(userset)));
        ui->textBrowser->insertPlainText("Min.");
        ui->textBrowser->setTextColor( QColor( "black" ) );
        updateRecord();
    }else if(current_state=="record"){
        current_intensity=current_record->getintensisty();
        current_session=current_record->getSession();
        current_type=current_record->getType();
        cout<<"session will start in 5 secounds....."<<endl;
        ui->textBrowser->clear();
        ui->textBrowser->setTextColor( QColor( "red" ) );
        ui->textBrowser->insertPlainText("The setting is successful!\n");
        string str="session_group:"+Session_group[current_session]->getName()+",session_type:"+Session_group[current_session]->types[current_type]->getName();
        str+=",intensity:"+to_string(current_intensity);
        ui->textBrowser->insertPlainText(QString::fromStdString(str));
        ui->textBrowser->setTextColor( QColor( "black" ) );
        updateRecord();
    }else if(current_state=="in_session"){
        if (current_session == 1) {
            QTime newTime(0,30,0);
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        } else if (current_session == 2) {
            QTime newTime(0,45,0);
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        }
         timer->start(1000);
    }
}
void MainWindow::updateRecord(){
    db->addRecord(current_user,current_session,current_type,current_intensity,QDateTime::currentDateTime());
    qInfo("The Record are saved successfully");


}

void MainWindow::record(){
    if(current_state=="open" || current_state=="record"){
        current_state="record";
        if(db->num!=0){
            Record* r[db->num];
            db->getRecordings(current_user,r);
            ui->textBrowser->clear();
            string str="";
            for(int i=0;i<db->num;i++){
                if(i==record_select){
                    current_record->setintensisty(r[i]->getintensisty());
                    current_record->setType(r[i]->getType());
                    current_record->setSession(r[i]->getSession());
                    str+=r[i]->getTime()+"  session_group:"+Session_group[r[i]->getSession()]->getName()+",";
                    str+=Session_group[r[i]->getSession()]->types[r[i]->getType()]->getName()+" intensity:"+to_string(r[i]->getintensisty())+"    *(be selected!)\n";
                }else{
                    str+=r[i]->getTime()+"  session_group:"+Session_group[r[i]->getSession()]->getName()+",";
                    str+=Session_group[r[i]->getSession()]->types[r[i]->getType()]->getName()+" intensity:"+to_string(r[i]->getintensisty())+"\n";
                }
            }
            ui->textBrowser->insertPlainText(QString::fromStdString(str));
        }
    }

}



void MainWindow::choose_session(){
    current_state="choose";
    if(current_session==0){
       current_session++;
       ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
        current_session++;
      }else{
        current_session=0;
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_session2(){
    current_state="choose";
    if(current_session==0){
       current_session=2;
       ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
        current_session--;
      }else{
        current_session--;
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_type(){
    current_state="choose type";
    if(current_type==0){
       current_type++;
       ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
        current_type++;
      }else if(current_type==2){
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
        current_type++;
      }else{
        current_type=0;
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_type2(){
    current_state="choose type";
    if(current_type==0){
       current_type=2;
       ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
        current_type--;
      }else if(current_type==2){
        current_type--;
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
     }else{
        current_type--;
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::save(){

    db->addProfile(current_user,current_session,current_type,current_intensity);
    qInfo("The personalized Settings are saved successfully");
    //db->getProfile(current_user);
}

void  MainWindow::session_color(){
    if(current_session==0){
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
    }else{
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
    }
}

void  MainWindow::sessiontype_color(){
    if(current_type==0){
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_type==2){
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
    }else{
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
    }
}
//yuan
void MainWindow::therapy(){
    current_state="in_session";
    therapy_timer=new QTimer();
    therapy_timer->start(Session_group[current_session]->getTime()*1000);
    stop();
    //current_session ==in_session
    // Qtimer  set timer
    //stop();
}
void MainWindow::updateUerdesign(){
    ui->textBrowser->clear();
    ui->textBrowser->insertPlainText("You can use the up and down buttons to design the time.\n");
    ui->textBrowser->insertPlainText(QString::fromStdString(to_string(userset)));
    ui->textBrowser->insertPlainText("Min.");
}

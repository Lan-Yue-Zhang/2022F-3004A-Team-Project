#include <iostream>
using namespace std;
#include <string>

#include "Frequency.h"

//constructor
Frequency::Frequency(string n){
    name=n;
}

//destructor
Frequency::~Frequency(){
    cout<<" "<<endl;
}

string Frequency::getName(){return name;}


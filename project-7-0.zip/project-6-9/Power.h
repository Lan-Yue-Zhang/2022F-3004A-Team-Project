#ifndef POWER_H
#define POWER_H
#include <iostream>
#include <string>

using namespace std;

class Power{   
    public:
        //constructor
        Power();
        //destructor
        ~Power();

        //getter
        int getBattery();
        void setBattery(int); //Change the amount of power to achieve charging and  power consumption
        bool check();

        //yuren 12/6
        void decrease_Battery(int); //battery = battery - int
    
        //other
        void print();
    private:
        int battery=100;
        
};

#endif

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Recording.h"
#include "Session.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    power1 = new Power();
    Session_group= new Session*[3];
    Session_group[0]=new Session("20 min",20);
    Session_group[1]=new Session("45 min",45);
    Session_group[2]=new Session("user design",0);
    //need change!!!!!!
    session=Session_group[current_session];

    db = new Recording();
    current_session=db->getProfile(current_user)[1];
    current_type=db->getProfile(current_user)[2];
    current_intensity=db->getProfile(current_user)[3];
    //yuan
    connect(ui->pushButton_15, &QPushButton::clicked,this,&MainWindow::connect_ear);
    connect(ui->pushButton_14, &QPushButton::clicked,this,&MainWindow::disconnect_ear);
    connect(ui->pushButton_1, &QPushButton::clicked,this,&MainWindow::selected_button);
    //wenyueyang
    connect(ui->pushButton_16, &QPushButton::clicked,this,&MainWindow::record);
    connect(ui->pushButton_13, &QPushButton::clicked,this,&MainWindow::save);

    //yuren
    connect(ui->toolButton, &QPushButton::pressed,this, &MainWindow::turn_on);
    timer = new QTimer(this);
    connect(ui->up, &QPushButton::pressed, this, &MainWindow::up);
    connect(ui->down, &QPushButton::pressed, this, &MainWindow::down);

//    current_state = "customize";
    current_selected = "1";
    design_time = new QTime(0,5,0);
    current_state = "close";
    connect(timer,SIGNAL(timeout()), this, SLOT(updateTime()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::updateTime() {
  QTime newTime = design_time->addSecs(-1);
  design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
  ui->textBrowser->clear();
  ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
  if(design_time->second() == 0){
      timer->stop();
  }

}

//yuan
void MainWindow::connect_ear(){
     is_connectEar=true;
      timer->start(1000);
    if(current_state=="in_session"){
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
        therapy();
        therapy_timer->start(Session_group[current_session]->getTime()*1000);
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }
    if(current_state=="disconnect"){
        current_state="in_session";
        is_connectEar=false;
        timer->start(1000);
        //therapy_timer->stop();
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
        ui->lineEdit->setText("session is running now!");
    }

}
void MainWindow::disconnect_ear(){
    if(current_state=="in_session"){
        ui->pushButton_9->setStyleSheet("background-color:red");
        ui->pushButton_10->setStyleSheet("background-color:red");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
         ui->lineEdit->setText("The session is not ending, please ending the session first!");
         current_state="disconnect";
         stop();
        // timer->stop();
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }
    is_connectEar=false;
}
void MainWindow::up(){
    //wenyueyang change
    if(current_state=="open"||current_state=="choose"){
        current_state="choose";
        ui->pushButton_20->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
        session_color();
        choose_session();
    }else if(current_state=="choose type"){
        ui->pushButton_4->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        sessiontype_color();
        choose_type();
    }else if(current_state=="userd"){
        userset+=5;
        updateUerdesign();
    }else if(current_state=="record"){
        if(record_select!=0){
            record_select--;
            record();
        }else{
            record_select=db->num-1;
            record();
        }
    }
    int temp_current = stoi(current_selected);
   if (current_state == "in_session") {

       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = ui->centralwidget->findChild<QLabel*>(buttonName);
       tempPushButton->setStyleSheet(" ");
       if (temp_current < 8){
           temp_current += 1;
       }
       else {
           temp_current = 1;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
       ui->textBrowser->clear();
       ui->textBrowser->insertPlainText(QString::fromStdString("intensity:" + to_string(temp_current)));
   } else if (current_state=="userd") {
       QTime newTime = design_time->addSecs(60*5);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
//       string str = design_time->toString("mm:ss").toStdString();
//       qInfo(design_time->toString("mm:ss").toLatin1());

   }
   current_selected = to_string(temp_current);
   current_intensity = stoi(current_selected);

     }

 //    //LANYUE
 void MainWindow:: down(){
    //wenyueyang change
     if(current_state=="open"||current_state=="choose"){
         ui->pushButton_20->setStyleSheet("background-color:rgb(255,255,255)");
         ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
         current_state="choose";
         session_color();
         choose_session2();
     }else if(current_state=="choose type"){
         ui->pushButton_4->setStyleSheet("background-color:rgb(255,255,255)");
         ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
         sessiontype_color();
         choose_type2();
     }else if(current_state=="userd"){
         if(userset>5){
             userset=userset-5;
             updateUerdesign();
         }else{
             userset=0;
             updateUerdesign();
         }
     }else if(current_state=="record"){
         if(record_select!=db->num-1){
             record_select++;
             record();
         }else{
             record_select=0;
             record();
         }
     }

     //



    int temp_current = stoi(current_selected);
   if (current_state == "in_session") {
       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = findChild<QLabel*>(buttonName);

           tempPushButton->setStyleSheet(" ");

       if (temp_current > 1){
           temp_current -= 1;
       }
       else {
           temp_current = 8;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
       ui->textBrowser->clear();
       ui->textBrowser->insertPlainText(QString::fromStdString("intensity:" + to_string(temp_current)));
   } else if (current_state=="userd") {
       QTime newTime = design_time->addSecs(-60*5);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
       }
   current_selected = to_string(temp_current);
   current_intensity = stoi(current_selected);
   }
//yuren
void MainWindow::power(){
    if(current_state=="close"){
        powerOn();
    }else if(current_state=="open"){
        turn_off();
    }
}
void MainWindow::turn_on(){ //when press power button call this
    if(current_state=="close"){
        QTimer::singleShot(2000, this, &MainWindow::checkTime); //after 2 seconds call checkTime()

    //wenyueYang change
    }else if(current_state=="choose type"){
        current_state="choose";
        current_type=0;
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
    }else if(current_state=="choose"){
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        current_state="open";
    }else if(current_state=="userd"){
       current_state="choose";
       userset=0;
       ui->textBrowser->clear();
    }else if(current_state=="record"){
        current_state="open";
        record_select=0;
        ui->textBrowser->clear();
    } else {
        turn_off();
    }
}

void MainWindow::checkTime(){ //after 2 seconds, button still being pressed
    if (ui->toolButton->isDown()) { //still in pressed position
        ui->checkBox->setCheckState(Qt::Checked);
        powerOn(); //turn on
    }
}

void MainWindow::powerOn(){
    ui->progressBar->setValue(100);     //set power to 100%
    //what else???
    current_state="open";
}
void MainWindow::push_8_w(){ ui->push_8->setStyleSheet("background: palette(window)"); }
void MainWindow::push_7_r(){ ui->push_7->setStyleSheet("background-color: rgb(250,175,175)"); }
void MainWindow::push_7_w(){ ui->push_7->setStyleSheet("background: palette(window)"); }
void MainWindow::push_6_r(){ ui->push_6->setStyleSheet("background-color: rgb(255,255,0)"); }
void MainWindow::push_6_w(){ ui->push_6->setStyleSheet("background: palette(window)"); }
void MainWindow::push_5_r(){ ui->push_5->setStyleSheet("background-color: rgb(255,255,0)"); }
void MainWindow::push_5_w(){ ui->push_5->setStyleSheet("background: palette(window)"); }
void MainWindow::push_4_r(){ ui->push_4->setStyleSheet("background-color: rgb(255,255,0)"); }
void MainWindow::push_4_w(){ ui->push_4->setStyleSheet("background: palette(window)"); }
void MainWindow::push_3_r(){ ui->push_3->setStyleSheet("background-color: rgb(138,226,52)"); }
void MainWindow::push_3_w(){ ui->push_3->setStyleSheet("background: palette(window)"); }
void MainWindow::push_2_r(){ ui->push_2->setStyleSheet("background-color: rgb(138,226,52)"); }
void MainWindow::push_2_w(){ ui->push_2->setStyleSheet("background: palette(window)"); }
void MainWindow::push_1_r(){ ui->push_1->setStyleSheet("background-color: rgb(138,226,52)"); }
void MainWindow::push_1_w(){ ui->push_1->setStyleSheet("background: palette(window)"); }

void MainWindow::turn_off(){
    updateRecord();
    if (current_state == "in_session"){
        //Soft off
        qInfo("Current status: in_session; turning off; soft off");
        if (current_intensity == 8){
            qInfo("intensity 8");
            QTimer::singleShot(1000, this, &MainWindow::push_8_w);
            QTimer::singleShot(1500, this, &MainWindow::push_7_r);
            QTimer::singleShot(2000, this, &MainWindow::push_7_w);
            QTimer::singleShot(2500, this, &MainWindow::push_6_r);
            QTimer::singleShot(3000, this, &MainWindow::push_6_w);
            QTimer::singleShot(3500, this, &MainWindow::push_5_r);
            QTimer::singleShot(4000, this, &MainWindow::push_5_w);
            QTimer::singleShot(4500, this, &MainWindow::push_4_r);
            QTimer::singleShot(5000, this, &MainWindow::push_4_w);
            QTimer::singleShot(5500, this, &MainWindow::push_3_r);
            QTimer::singleShot(6000, this, &MainWindow::push_3_w);
            QTimer::singleShot(6500, this, &MainWindow::push_2_r);
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 7){
            QTimer::singleShot(2000, this, &MainWindow::push_7_w);
            QTimer::singleShot(2500, this, &MainWindow::push_6_r);
            QTimer::singleShot(3000, this, &MainWindow::push_6_w);
            QTimer::singleShot(3500, this, &MainWindow::push_5_r);
            QTimer::singleShot(4000, this, &MainWindow::push_5_w);
            QTimer::singleShot(4500, this, &MainWindow::push_4_r);
            QTimer::singleShot(5000, this, &MainWindow::push_4_w);
            QTimer::singleShot(5500, this, &MainWindow::push_3_r);
            QTimer::singleShot(6000, this, &MainWindow::push_3_w);
            QTimer::singleShot(6500, this, &MainWindow::push_2_r);
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 6){
            QTimer::singleShot(3000, this, &MainWindow::push_6_w);
            QTimer::singleShot(3500, this, &MainWindow::push_5_r);
            QTimer::singleShot(4000, this, &MainWindow::push_5_w);
            QTimer::singleShot(4500, this, &MainWindow::push_4_r);
            QTimer::singleShot(5000, this, &MainWindow::push_4_w);
            QTimer::singleShot(5500, this, &MainWindow::push_3_r);
            QTimer::singleShot(6000, this, &MainWindow::push_3_w);
            QTimer::singleShot(6500, this, &MainWindow::push_2_r);
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 5){
            QTimer::singleShot(4000, this, &MainWindow::push_5_w);
            QTimer::singleShot(4500, this, &MainWindow::push_4_r);
            QTimer::singleShot(5000, this, &MainWindow::push_4_w);
            QTimer::singleShot(5500, this, &MainWindow::push_3_r);
            QTimer::singleShot(6000, this, &MainWindow::push_3_w);
            QTimer::singleShot(6500, this, &MainWindow::push_2_r);
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 4){
            QTimer::singleShot(5000, this, &MainWindow::push_4_w);
            QTimer::singleShot(5500, this, &MainWindow::push_3_r);
            QTimer::singleShot(6000, this, &MainWindow::push_3_w);
            QTimer::singleShot(6500, this, &MainWindow::push_2_r);
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 3){
            QTimer::singleShot(6000, this, &MainWindow::push_3_w);
            QTimer::singleShot(6500, this, &MainWindow::push_2_r);
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 2){
            QTimer::singleShot(7000, this, &MainWindow::push_2_w);
            QTimer::singleShot(7500, this, &MainWindow::push_1_r);
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        } else if (current_intensity == 1){
            QTimer::singleShot(8000, this, &MainWindow::push_1_w);

            QTimer::singleShot(10000, this, &MainWindow::actual_off);
        }
    } else {
        qInfo("Current status: not in_session; turning off");
        QTimer::singleShot(2000, this, &MainWindow::actual_off); //press and hold 2 secs
    }
}
void MainWindow::actual_off(){
    if (ui->toolButton->isDown()) { //still in pressed position
        qInfo("Turning off");
        ui->progressBar->setValue(0);
        current_state = "close";
        ui->checkBox->setChecked(false);
        ui->pushButton_1->setStyleSheet("background: palette(window)");
        ui->pushButton_18->setStyleSheet("background: palette(window)");
        ui->pushButton_19->setStyleSheet("background: palette(window)");
        ui->pushButton_20->setStyleSheet("background: palette(window)");
        ui->pushButton_4->setStyleSheet("background: palette(window)");
        ui->pushButton_5->setStyleSheet("background: palette(window)");
        ui->pushButton_6->setStyleSheet("background: palette(window)");
        ui->pushButton_7->setStyleSheet("background: palette(window)");

        ui->push_1->setStyleSheet("background: palette(window)");
        ui->push_2->setStyleSheet("background: palette(window)");
        ui->push_3->setStyleSheet("background: palette(window)");
        ui->push_4->setStyleSheet("background: palette(window)");
        ui->push_5->setStyleSheet("background: palette(window)");
        ui->push_6->setStyleSheet("background: palette(window)");
        ui->push_7->setStyleSheet("background: palette(window)");
        ui->push_8->setStyleSheet("background: palette(window)");

        ui->pushButton_9->setStyleSheet("background: palette(window)");
        ui->pushButton_10->setStyleSheet("background: palette(window)");
        ui->pushButton_11->setStyleSheet("background: palette(window)");
        ui->pushButton_12->setStyleSheet("background: palette(window)");

        ui->textBrowser->clear();
        timer->stop();
    }
}
//yuren 12/5
void MainWindow::change_power(){
    //length of therapy     int current_session = 20, 45;
    //intensity             int current_intensity = 1-8;
    //connection to skin    bool is_connectEar = true & false;
    //hertz                 string name = "9-11 Hz"; "18-22 Hz"; "6-8 Hz"; "0.5-3 Hz"   Frequency::&getName()
    if (is_connectEar == true && current_state == "in_session"){
        if (Session_group[current_session]->getTime() == 20){ //20 mins
            if (Session_group[current_session]->types[current_type]->getName() == "9-11 Hz"){ //alpha
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(2.6);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(2.5); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(2.4);
                    ui->progressBar->setValue(power1->getBattery());
                }
            } else if (Session_group[current_session]->types[current_type]->getName() == "18-22 Hz"){ //beta 2
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(5.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(5); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(4.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            } else if (Session_group[current_session]->types[current_type]->getName() == "6-8 Hz"){ //theta
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(2.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(2); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(1.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            } else if (Session_group[current_session]->types[current_type]->getName() == "0.5-3 Hz"){ //sub-delta
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(1.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(1); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(0.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            }
        } else if (Session_group[current_session]->getTime() == 45) {  //45 minis
            if (Session_group[current_session]->types[current_type]->getName() == "9-11 Hz"){
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(5.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(5); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(4.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            } else if (Session_group[current_session]->types[current_type]->getName() == "18-22 Hz"){
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(10.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(10); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(9.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            } else if (Session_group[current_session]->types[current_type]->getName() == "6-8 Hz"){
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(4.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(4); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(3.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            } else if (Session_group[current_session]->types[current_type]->getName() == "0.5-3 Hz"){
                if (7 <= current_intensity && current_intensity <= 8){
                    power1->decrease_Battery(2.1);
                    ui->progressBar->setValue(power1->getBattery());
                } else if (4 <= current_intensity && current_intensity <= 6){
                    power1->decrease_Battery(2); //~~~~~~real~~~~~
                    ui->progressBar->setValue(power1->getBattery());
                } else if (1 <= current_intensity && current_intensity <= 2){
                    power1->decrease_Battery(1.9);
                    ui->progressBar->setValue(power1->getBattery());
                }
            }
        } else { //customize time
            int custom_time = Session_group[current_session]->getTime();
            if (Session_group[current_session]->types[current_type]->getName() == "9-11 Hz"){
                power1->decrease_Battery(custom_time*0.125);
                ui->progressBar->setValue(power1->getBattery());
            } else if (Session_group[current_session]->types[current_type]->getName() == "18-22 Hz"){
                power1->decrease_Battery(custom_time*0.25);
                ui->progressBar->setValue(power1->getBattery());
            } else if (Session_group[current_session]->types[current_type]->getName() == "6-8 Hz"){
                power1->decrease_Battery(custom_time*0.1);
                ui->progressBar->setValue(power1->getBattery());
            } else if (Session_group[current_session]->types[current_type]->getName() == "0.5-3 Hz"){
                power1->decrease_Battery(custom_time*0.05);
                ui->progressBar->setValue(power1->getBattery());
            }
        }
    } else {
        //do nothing, do not consume battery
    }
}
//yuren 12/5 2


//yuan
void MainWindow::stop(){
    if(current_state=="in_session"){
       turn_off();
    }else{
        ui->lineEdit->setText("Session has benn Stopped!");
      }
}

//yuan
void MainWindow::low_power(){
    if(current_state=="open" && power1->check()==true){
        ui->progressBar->setValue(5);
        ui->progressBar->setStyleSheet("background-color:red");
        ui->lineEdit->setText("Low Power now, Please charge new Battery!");
    }
    if(current_state=="open" && current_state=="in_session"){
        stop();
        change_power();
        ui->lineEdit->setText("session is running now! Turn off session first!");
    }    //display 2 bars and blink
    //check current state ="session" warning, replaced battery
}

void MainWindow::selected_button(){
//wenyueyang
    if(current_state=="choose"){
        cout<<"choose session:"<<current_session+1<<endl;
        if(current_session!=2){
            current_state="choose type";
            sessiontype_color();
        }else{
            current_state="userd";
            updateUerdesign();
        }
    }else if(current_state=="choose type"){
        ui->textBrowser->clear();
        cout<<"choose session:"<<current_session+1<<endl;
        cout<<"choose type:"<<current_type+1<<endl;
        cout<<"session will start in 5 secounds....."<<endl;
        int temp_current = stoi(current_selected);
        current_state="in_session";
        QString buttonName = "push_" + QString::number(temp_current);
        QLabel* tempPushButton = findChild<QLabel*>(buttonName);

        if (temp_current >= 7) {
            tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
        }
        else if (temp_current >= 4){
            tempPushButton->setStyleSheet("background-color: yellow");
        }
        else {
            tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
        }
    }else if(current_state=="userd"){
        current_state="choose type";
        ui->textBrowser->clear();
        ui->textBrowser->setTextColor( QColor( "red" ) );
        ui->textBrowser->insertPlainText("The setting is successful! your session time is:");
        Session_group[2]->setTime(userset);
        ui->textBrowser->insertPlainText(QString::fromStdString(to_string(userset)));
        ui->textBrowser->insertPlainText("Min.");
        ui->textBrowser->setTextColor( QColor( "black" ) );
    }else if(current_state=="record"){
        current_intensity=current_record->getintensisty();
        current_session=current_record->getSession();
        current_type=current_record->getType();
        cout<<"session will start in 5 secounds....."<<endl;
        ui->textBrowser->clear();
        ui->textBrowser->setTextColor( QColor( "red" ) );
        ui->textBrowser->insertPlainText("The setting is successful!\n");
        string str="session_group:"+Session_group[current_session]->getName()+",session_type:"+Session_group[current_session]->types[current_type]->getName();
        str+=",intensity:"+to_string(current_intensity);
        ui->textBrowser->insertPlainText(QString::fromStdString(str));
        ui->textBrowser->setTextColor( QColor( "black" ) );

        if(current_session==0){
            ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
        }else if(current_session==1){
            ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
        }else if (current_session==2){
            ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
        }
        if(current_type==0){
            ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
        }else if(current_type==1){
            ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
        }else if(current_type==2){
            ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
        }else if(current_type==3){
            ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
        }
        int temp_current = stoi(to_string(current_intensity));
        current_state="in_session";
        QString buttonName = "push_" + QString::number(temp_current);
        QLabel* tempPushButton = findChild<QLabel*>(buttonName);

        if (temp_current >= 7) {
            tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
        }
        else if (temp_current >= 4){
            tempPushButton->setStyleSheet("background-color: yellow");
        }
        else {
            tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
        }

        if (current_session == 1) {
            QTime newTime(0,45,0);
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        } else if (current_session == 0) {
            QTime newTime(0,20,0);
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        }else{
            QTime newTime(0,Session_group[current_session]->getTime(),0);
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        }
        timer->start(1000);
    }else if(current_state=="in_session"){
      if (current_session == 1) {
            QTime newTime(0,45,0);
            light_blink();
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        } else if (current_session == 0) {
            QTime newTime(0,20,0);
            design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
            ui->textBrowser->clear();
            ui->textBrowser->insertPlainText("\n" + design_time->toString("hh:mm:ss"));
        }
         //timer->start(1000);
      if(is_connectEar==true){
          timer->start(1000);
      }else if(is_connectEar==false){
          timer->stop();
     }
    }


}
void MainWindow::updateRecord(){
    db->addRecord(current_user,current_session,current_type,current_intensity,QDateTime::currentDateTime());
    qInfo("The Record are saved successfully");


}

void MainWindow::record(){
    if(current_state=="open" || current_state=="record"){
        current_state="record";
        if(db->num!=0){
            Record* r[db->num];
            db->getRecordings(current_user,r);
            ui->textBrowser->clear();
            string str="";
            for(int i=0;i<db->num;i++){
                if(i==record_select){
                    current_record->setintensisty(r[i]->getintensisty());
                    current_record->setType(r[i]->getType());
                    current_record->setSession(r[i]->getSession());
                    str+=r[i]->getTime()+"  session_group:"+Session_group[r[i]->getSession()]->getName()+",";
                    str+=Session_group[r[i]->getSession()]->types[r[i]->getType()]->getName()+" intensity:"+to_string(r[i]->getintensisty())+"    *(be selected!)\n";
                }else{
                    str+=r[i]->getTime()+"  session_group:"+Session_group[r[i]->getSession()]->getName()+",";
                    str+=Session_group[r[i]->getSession()]->types[r[i]->getType()]->getName()+" intensity:"+to_string(r[i]->getintensisty())+"\n";
                }
            }
            ui->textBrowser->insertPlainText(QString::fromStdString(str));
        }
    }

}



void MainWindow::choose_session(){
    current_state="choose";
    if(current_session==0){
       current_session++;
       ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
        current_session++;
      }else{
        current_session=0;
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_session2(){
    current_state="choose";
    if(current_session==0){
       current_session=2;
       ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
        current_session--;
      }else{
        current_session--;
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_type(){
    current_state="choose type";
    if(current_type==0){
       current_type++;
       ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
        current_type++;
      }else if(current_type==2){
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
        current_type++;
      }else{
        current_type=0;
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_type2(){
    current_state="choose type";
    if(current_type==0){
       current_type=3;
       ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
        current_type--;
      }else if(current_type==2){
        current_type--;
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
     }else{
        current_type--;
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::save(){

    db->addProfile(current_user,current_session,current_type,current_intensity);
    qInfo("The personalized Settings are saved successfully");
    //db->getProfile(current_user);
}

void  MainWindow::session_color(){
    if(current_session==0){
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
    }else{
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
    }
}

void  MainWindow::sessiontype_color(){
    if(current_type==0){
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_type==2){
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
    }else{
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
    }
}
//yuan---change
void MainWindow::therapy(){
    current_state="in_session";
    if(is_connectEar==true){
        timer->start();
        therapy_timer=new QTimer();
        therapy_timer->start(Session_group[current_session]->getTime()*1000);
    }else{
       therapy_timer->stop();
       timer->stop();
       //stop();
    }
}
void MainWindow::updateUerdesign(){
    ui->textBrowser->clear();
    ui->textBrowser->insertPlainText("You can use the up and down buttons to design the time.\n");
    ui->textBrowser->insertPlainText(QString::fromStdString(to_string(userset)));
    ui->textBrowser->insertPlainText("Min.");
}
//yuan
void MainWindow::light_blink(){
    if(current_state=="in_session"&& is_connectEar==false){
                timer->stop();
               ui->pushButton_9->setStyleSheet("background-color:red");
               ui->pushButton_10->setStyleSheet("background-color:red");
               ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
               ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
      }else{
               ui->pushButton_9->setStyleSheet("background-color: rgb(255,255,255)");
               ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
               ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
               ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
    }
}

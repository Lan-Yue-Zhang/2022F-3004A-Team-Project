#ifndef POWER_H
#define POWER_H
#include<string>
using namespace std;

class POWER{
public:
    POWER();
    ~POWER();
    int getBattery();
    void setBattery(int);

private:
    int battery=100;
};
#endif


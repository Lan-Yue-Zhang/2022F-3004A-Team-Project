#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    power1 = new POWER();
    session=new SESSION("session");
    connect(ui->pushButton_15, &QPushButton::clicked,this,&MainWindow::connect_ear);
    connect(ui->pushButton_14, &QPushButton::clicked,this,&MainWindow::disconnect_ear);
//    connect(ui->pushButton_1, &QPushButton::clicked,this,&MainWindow::selected_button);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::connect_ear(){
    if(current_state!=session->getName()){
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }

}

void MainWindow::disconnect_ear(){
   if(current_state==session->getName()){
        stop();
        printf("The session is not ending, please ending the session first!");
    }else{
       ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
       ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
   }
}
void MainWindow::up(){

}
void MainWindow::down(){}
void MainWindow::power(){
    if(current_state=="close"){
        turn_on();
    }else if(current_state=="open"){
        turn_off();
    }else if(current_state==session->getName()){
        //change session group
    }
}
void MainWindow::turn_on(){

}
void MainWindow::turn_off(){}
void MainWindow::change_power(){}
void MainWindow::stop(){
    if(current_state==session->getName()){
       turn_off();
    printf("Ending Session Nows!");
    }
    else{
       printf("Session has benn Stopped!");
    }
}

void MainWindow::low_power(){
    //chek battrey level
    //if battrey level <20 mins
    //display 2 bars and blink
    //check current state ="sessiom" warning, replaced battery
}

void MainWindow::selected_button(){
//flash highlighted button
//add a QTimer running 5 seconds
//ui->pushButton_1->setStyleSheet("background-color: rgb(255,255,153)");
}


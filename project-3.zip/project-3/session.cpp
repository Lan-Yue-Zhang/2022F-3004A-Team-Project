#include"session.h"
SESSION::SESSION(string name){
    this->name=name;
}
void SESSION::setName(string n){
    this->name=n;

}
const string& SESSION::getName(){
    return name;
}

#ifndef SESSION_H
#define SESSION_H
#include <string>
using namespace std;
class SESSION{
public:
    SESSION(string);
    const string& getName();
    void setName(string);

private:
    string name;
};

#endif // SESSION_H

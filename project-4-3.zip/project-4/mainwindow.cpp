#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Recording.h"
#include "Session.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    power1 = new Power();
    session=new Session("session");
    db = new Recording();

    connect(ui->pushButton_15, &QPushButton::clicked,this,&MainWindow::connect_ear);
    connect(ui->pushButton_14, &QPushButton::clicked,this,&MainWindow::disconnect_ear);
    connect(ui->pushButton_1, &QPushButton::clicked,this,&MainWindow::selected_button);
    connect(ui->pushButton_16, &QPushButton::clicked,this,&MainWindow::record);
    //yuren
    connect(ui->toolButton, &QPushButton::pressed,this, &MainWindow::turn_on);
    timer = new QTimer(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::connect_ear(){
    if(current_state!=session->getName()){
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }

}

void MainWindow::disconnect_ear(){
   if(current_state==session->getName()){
        stop();
        printf("The session is not ending, please ending the session first!");
    }else{
       ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
       ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
   }
}
void MainWindow::up(){

}
void MainWindow::down(){

}
//yuren
void MainWindow::power(){
    if(current_state=="close"){
        powerOn();
    }else if(current_state=="open"){
        turn_off();
    }else if(current_state==session->getName()){
        //change session group
    }
}
void MainWindow::turn_on(){ //when press power button call this
    QTimer::singleShot(2000, this, &MainWindow::checkTime); //after 2 seconds call checkTime()
}
void MainWindow::checkTime(){ //after 2 seconds, button still being pressed
    if (ui->toolButton->isDown()) { //still in pressed position
        ui->checkBox->setCheckState(Qt::Checked);
        powerOn(); //turn on
    }
}

void MainWindow::powerOn(){
    ui->progressBar->setValue(100);     //set power to 100%
    //what else???
}
void MainWindow::turn_off(){
    //Change sessions color to black

    //Change time color to black

    //Change intensity color to black
    ui->label_10->setStyleSheet("color:black");
    ui->label_11->setStyleSheet("color:black");
    ui->label_12->setStyleSheet("color:black");
    ui->label_13->setStyleSheet("color:black");
    ui->label_5->setStyleSheet("color:black");
    ui->label_6->setStyleSheet("color:black");
    ui->label_8->setStyleSheet("color:black");
    ui->label_9->setStyleSheet("color:black");
    //Device power button to unchecked
    ui->checkBox->setChecked(false);
}
void MainWindow::change_power(){
    if (current_state == ""){ //doing nothing
        //battery bar does not change
    } else if (current_state == ""){ //doing work
        session->getTime(); //length of therapy
        //Intensity.getlevel(); //intensity ??? use what object ???
        //connections to skin ???
    }
}

//yuren

void MainWindow::stop(){
    if(current_state==session->getName()){
       turn_off();
    printf("Ending Session Nows!");
    }
    else{
       printf("Session has benn Stopped!");
    }
}

void MainWindow::low_power(){
    //chek battrey level
    //if battrey level <20 mins
    //display 2 bars and blink
    //check current state ="sessiom" warning, replaced battery
}

void MainWindow::selected_button(){
//flash highlighted button
//add a QTimer running 5 seconds
ui->pushButton_1->setStyleSheet("background-color: rgb(255,255,153)");
}

void MainWindow::record(){
    //for test
    db->getRecordings(1);
    db->getRecordings(2);
}

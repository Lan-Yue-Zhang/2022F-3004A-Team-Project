#ifndef SESSION_H
#define SESSION_H
#include <iostream>
#include <string>
#include "Intensity.h"

using namespace std;

class Session{   
    public:
        //constructor
        Session(string);
        //destructor
        ~Session();

        //getter
        int getTime();
        void setTime(int); //Change the amount of power to achieve charging and  power consumption
        string getName();

    private:
        string name;
        int time;
        Intensity** Intensities;

        
};

#endif

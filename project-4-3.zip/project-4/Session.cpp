#include <iostream>
using namespace std;
#include <string>

#include "Session.h"

//constructor
Session::Session(string n,int t){
    name=n;
    time=t;
    Intensities= new Intensity*[8];
}

//destructor
Session::~Session(){
    cout<<" "<<endl;
}

//getter
void Session::setTime(int n){time=n;}
int Session::getTime(){return time;}
string Session::getTime(){return name;}


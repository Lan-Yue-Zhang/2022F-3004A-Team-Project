#include <iostream>
using namespace std;
#include <string>

#include "record.h"

//constructor
Record::Record(string ti,int t,int u,int s,int i){
    time=ti;
    session=s;
    type= t;
    intensisty=i;
    uid=u;

}

//destructor
Record::~Record(){
    cout<<" "<<endl;
}

//getter
int Record::getSession(){return session;}
int Record::getType(){return type;}
int Record::getintensisty(){return intensisty;}
int Record::getuid(){return uid;}
string Record::getTime(){return time;}

void Record::setSession(int s){session=s;}
void Record::setType(int t ){type=t;}
void Record::setintensisty(int i ){intensisty=i;}

#ifndef SESSION_H
#define SESSION_H
#include <iostream>
#include <string>
#include "Frequency.h"

using namespace std;

class Session{   
    public:
        //constructor
        Session(string,int);
        //destructor
        ~Session();

        //getter
        int getTime();
        void setTime(int); //Change the amount of power to achieve charging and  power consumption
        string getName();
        Frequency** types;

    private:
        string name;
        int time;


        
};

#endif

#ifndef BUTTON_H
#define BUTTON_H
#include<string>
using namespace std;

class BUTTON{
public:
    BUTTON(string);
    BUTTON();
    const string& getName();
    bool getState();
    void switch_on();
    void switch_off();
    void print();
private:
    string name;
    bool on_off;
};

#endif // BUTTON_H

#include"power.h"
POWER::POWER(){
    this->battery=battery;
}
POWER::~POWER(){

}
void POWER::setBattery(int battery){
    this->battery=battery;
}

int POWER::getBattery(){
    return battery;
}

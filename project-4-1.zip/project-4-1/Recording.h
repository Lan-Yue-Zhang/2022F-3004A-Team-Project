#ifndef RECORDING_H
#define RECORDING_H

#include <QString>
#include <QSqlDatabase>
#include <QDateTime>
#include <QDebug>
#include <QSqlQuery>
#include <QList>
#include <QApplication>

class Recording {

public:
    const QString DATE_FORMAT = "yyyy-MM-dd hh:mm";
    static const QString DATABASE_PATH;

    Recording();
    void getRecordings(int);
    void getProfile(int );


private:
    QSqlDatabase db;
    bool Init();

};

#endif


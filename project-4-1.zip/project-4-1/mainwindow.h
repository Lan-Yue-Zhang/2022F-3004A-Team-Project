#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"Session.h"
#include"Power.h"
#include"Recording.h"
#include"button.h"
#include<string>
#include<QTime>
#include<QTimer>
#include<iostream>
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Power *power1;
    Session *session;
    Recording* db;
    void connect_ear();
    void disconnect_ear();
    void up();
    void down();
    void power();
    void turn_on();
    void turn_off();
    void change_power();


    void record();

    void selected_button();
    void stop();
    void low_power();



private:
    Ui::MainWindow *ui;
    string current_state;
    string current_selected;

    QTime *design_time;
    QTimer *timer;
};
#endif // MAINWINDOW_H

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"Recording.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);

    power1 = new Power();
    session=new Session("session");
    db = new Recording();
    connect(ui->pushButton_15, &QPushButton::clicked,this,&MainWindow::connect_ear);
    connect(ui->pushButton_14, &QPushButton::clicked,this,&MainWindow::disconnect_ear);
    connect(ui->pushButton_1, &QPushButton::clicked,this,&MainWindow::selected_button);
    connect(ui->pushButton_16, &QPushButton::clicked,this,&MainWindow::record);

    connect(ui->up, &QPushButton::pressed, this, &MainWindow::up);
    connect(ui->down, &QPushButton::pressed, this, &MainWindow::down);
    current_state = "customize";
    current_selected = "1";
    timer = new QTimer();
    design_time = new QTime(0,0,0);
}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::connect_ear(){
    if(current_state!=session->getTime()){
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }

}

void MainWindow::disconnect_ear(){
   if(current_state==session->getTime()){
        stop();
        printf("The session is not ending, please ending the session first!");
    }else{
       ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
       ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
   }
}
void MainWindow::up(){
    int temp_current = stoi(current_selected);
   if (current_state == "session") {

       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = ui->centralwidget->findChild<QLabel*>(buttonName);
       tempPushButton->setStyleSheet(" ");
       if (temp_current < 8){
           temp_current += 1;
       }
       else {
           temp_current = 1;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
   } else if (current_state == "customize") {
 //       int currentTimerCount = 0;
 //       currentTimerCount += 30;
 //       QTime newTime(0,currentTimerCount/60,currentTimerCount%60);
 //       timeString = newTime->toString("mm:ss");
 //       scene->addText(timeString);


 //       QTime newTime = Time->addSecs(60*currentTimerCount);
 //       Time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
 //       ui->countdown->setPlainText(Time->toString("mm:ss"));
       QTime newTime = design_time->addSecs(60*10);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       string str = design_time->toString("mm:ss").toStdString();
       qInfo(design_time->toString("mm:ss").toLatin1());

       }
   current_selected = to_string(temp_current);
     }

 //    //LANYUE
 void MainWindow:: down(){

    int temp_current = stoi(current_selected);
   if (current_state == "session") {
       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = findChild<QLabel*>(buttonName);

           tempPushButton->setStyleSheet(" ");

       if (temp_current > 1){
           temp_current -= 1;
       }
       else {
           temp_current = 8;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
   } else if (current_state == "customize") {
 //       int currentTimerCount = 0;
 //       currentTimerCount += 30;
 //       QTime newTime(0,currentTimerCount/60,currentTimerCount%60);
 //       timeString = newTime->toString("mm:ss");
 //       scene->addText(timeString);


 //       QTime newTime = Time->addSecs(60*currentTimerCount);
 //       Time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
 //       ui->countdown->setPlainText(Time->toString("mm:ss"));
       QTime newTime = design_time->addSecs(-60*10);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       string str = design_time->toString("mm:ss").toStdString();
       qInfo(design_time->toString("mm:ss").toLatin1());
       }
   current_selected = to_string(temp_current);
   }
void MainWindow::power(){
    if(current_state=="close"){
        turn_on();
    }else if(current_state=="open"){
        turn_off();
    }else if(current_state==session->getTime()){
        //change session group
    }
}
void MainWindow::turn_on(){

}
void MainWindow::turn_off(){}
void MainWindow::change_power(){}
void MainWindow::stop(){
    if(current_state==session->getTime()){
       turn_off();
    printf("Ending Session Nows!");
    }
    else{
       printf("Session has benn Stopped!");
    }
}

void MainWindow::low_power(){
    //chek battrey level
    //if battrey level <20 mins
    //display 2 bars and blink
    //check current state ="sessiom" warning, replaced battery
}

void MainWindow::selected_button(){
//flash highlighted button
//add a QTimer running 5 seconds
ui->pushButton_1->setStyleSheet("background-color: rgb(255,255,153)");
}

void MainWindow::record(){
    //for test
    db->getRecordings(1);
    db->getRecordings(2);
}


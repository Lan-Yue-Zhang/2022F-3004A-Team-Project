#include "Recording.h"
using namespace std;
#include <iostream>

const QString Recording::DATABASE_PATH = "/database/teamworkDb.db";
Recording::Recording() {
    db= QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("teamworkDb.db");
    if( !db.open()){
        throw "db.open failed.";
    }
    if( !Init()){
        throw "Error:can  not be initialized";
    }
}

bool Recording::Init() {
    db.transaction();
    QSqlQuery query;
    query.exec("CREATE TABLE IF NOT EXISTS  profiles(uid int primary key, session int, intensity int)");
    query.exec("CREATE TABLE IF NOT EXISTS  record(id int primary key,time TEXT NOT NULL, uid int, session int, intensity int)");
    query.exec("insert into profiles values(1, 20, 1)");
    query.exec("insert into profiles values(2, 20, 1)");
    //for test
    
    query.exec("insert into record values(1,'s', 1, 20,2)");
    //query.bindValue(":time", QDateTime::currentDateTime());
    query.exec("insert into record values(2,'a', 2, 40,2)");
    //query.bindValue(":time2", QDateTime::currentDateTime());

    return db.commit();
}


void Recording::getProfile(int id) {

    db.transaction();
    QSqlQuery query;
    query.prepare("SELECT * FROM profiles WHERE uid=:uid");
    query.bindValue(":uid", id);
    query.exec();

    if (!db.commit()) {
        throw "Error: Query failed to execute";
    }

}


void Recording::getRecordings(int id) {

    db.transaction();
    QSqlQuery query;
    query.prepare("SELECT * FROM record WHERE uid=:uid");
    query.bindValue(":uid", id);
    query.exec();
    while (query.next()) {
        cout<<"user:"<<query.value(2).toString().toInt()<<" session:"<<query.value(3).toString().toInt()<< "min, intensity:"<<query.value(4).toString().toInt()<<endl;
    }

}

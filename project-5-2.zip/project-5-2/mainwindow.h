#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <iostream>
#include <QMainWindow>
#include <QTimer>
#include"Session.h"
#include"Power.h"
#include"Recording.h"
#include"button.h"
#include<string>
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    Power *power1;
    Session** Session_group;

    Recording* db;
    //yuren
    QTimer *timer;

    void connect_ear();
    void disconnect_ear();
    void up();
    void down();

    //yuren
    void checkTime();
    void power();
    void turn_on();
    void powerOn();
    void turn_off();
    void change_power();

    void record();

    void selected_button();
    void stop();
    void low_power();

    //wenyue Yang
    void choose_session();
    void choose_session2();
    void choose_type();
    void choose_type2();
    void save();
    void session_color();
    void sessiontype_color();
    void therapy();

private slots:


private:
    Ui::MainWindow *ui;
    string current_state;
    string current_selected;
    //prof
    int current_user=1;
    int current_session; //user choose index
    int current_type;
    int current_intensity;
    //
    Session* session;
    QTime* design_time;
    QTimer* therapy_timer;

};
#endif // MAINWINDOW_H

#include "Recording.h"
using namespace std;
#include <iostream>

const QString Recording::DATABASE_PATH = "/database/teamworkDb.db";
Recording::Recording() {
    db= QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("teamworkDb.db");
    if( !db.open()){
        throw "db.open failed.";
    }
    if( !Init()){
        throw "Error:can  not be initialized";
    }
}

bool Recording::Init() {
    db.transaction();
    QSqlQuery query;
    query.exec("drop table IF  EXISTS profiles");
    query.exec("drop table IF  EXISTS record");
    query.exec("CREATE TABLE IF NOT EXISTS  profiles(uid int primary key, session int, type int,intensity int)");
    query.exec("CREATE TABLE IF NOT EXISTS  record(id int primary key,time TEXT NOT NULL, uid int, session int, intensity int)");
    //for test
    query.exec("INSERT OR REPLACE into profiles values(1, 0 ,0,1)");
    query.exec("INSERT OR REPLACE into profiles values(2, 0,0,1)");

    return db.commit();
}


int* Recording::getProfile(int id){

    db.transaction();
    QSqlQuery query;
    query.prepare("SELECT * FROM profiles WHERE uid=:uid");
    query.bindValue(":uid", id);
    query.exec();
    int* profile;
    profile=new int[4];
    while (query.next()){
        cout<<"user:"<<query.value(0).toString().toInt()<<" session:"<<query.value(1).toString().toInt()<< " min,type: "<<query.value(2).toString().toInt()<<",intnsity:"<<query.value(3).toString().toInt()<<endl;
        profile[0]=query.value(0).toString().toInt();
        profile[1]=query.value(1).toString().toInt();
        profile[2]=query.value(2).toString().toInt();
        profile[3]=query.value(3).toString().toInt();


    }
    if (!db.commit()) {
        throw "Error: Query failed to execute";
    }
    return profile;

}


void Recording::getRecordings(int id) {

    db.transaction();
    QSqlQuery query;
    query.prepare("SELECT * FROM record WHERE uid=:uid");
    query.bindValue(":uid", id);
    query.exec();
    while (query.next()) {
        cout<<"user:"<<query.value(2).toString().toInt()<<" session:"<<query.value(3).toString().toInt()<< "min, intensity:"<<query.value(4).toString().toInt()<<endl;
    }

}

void Recording::addProfile(int id,int s,int y,int i){
    cout<<id<<endl;
    db.transaction();
    QSqlQuery query;
    query.prepare("REPLACE INTO profiles(uid, session, type,intensity) VALUES (:uid, :session, :type,:intensity);");
    query.bindValue(":uid", id);
    query.bindValue(":session", s);
    query.bindValue(":type", y);
    query.bindValue(":intnsity", i);
    query.exec();
    if (!db.commit()) {
        throw "Error: Query failed to execute";
    }
}



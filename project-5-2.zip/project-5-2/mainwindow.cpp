#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "Recording.h"
#include "Session.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    power1 = new Power();
    Session_group= new Session*[3];
    Session_group[0]=new Session("1",20);
    Session_group[1]=new Session("2",45);
    Session_group[2]=new Session("user",0);
    //need change!!!!!!
    session=Session_group[current_session];

    db = new Recording();
    current_session=db->getProfile(current_user)[1];
    current_type=db->getProfile(current_user)[2];
    current_intensity=db->getProfile(current_user)[3];
    //yuan
    connect(ui->pushButton_15, &QPushButton::clicked,this,&MainWindow::connect_ear);
    connect(ui->pushButton_14, &QPushButton::clicked,this,&MainWindow::disconnect_ear);
    connect(ui->pushButton_1, &QPushButton::clicked,this,&MainWindow::selected_button);
    //wenyueyang
    connect(ui->pushButton_16, &QPushButton::clicked,this,&MainWindow::record);
    connect(ui->pushButton_13, &QPushButton::clicked,this,&MainWindow::save);

    //yuren
    connect(ui->toolButton, &QPushButton::pressed,this, &MainWindow::turn_on);
    timer = new QTimer(this);
    connect(ui->up, &QPushButton::pressed, this, &MainWindow::up);
    connect(ui->down, &QPushButton::pressed, this, &MainWindow::down);

//    current_state = "customize";
    current_selected = "1";
    design_time = new QTime(0,0,0);
    current_state = "close";
}

MainWindow::~MainWindow()
{
    delete ui;
}
//yuan
void MainWindow::connect_ear(){
    if(current_state=="open"){
        ui->pushButton_9->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,0,0)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,0)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(102,204,0)");
    }else{
        ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
    }
    if(current_state=="disconnect"){
        current_state="in_session";
        therapy();
        ui->lineEdit->setText("session is running now!");
        therapy_timer->start(Session_group[current_session]->getTime()*1000);
    }
}
//yuan
void MainWindow::disconnect_ear(){
   if(current_state=="in_session"){
        stop();
        ui->lineEdit->setText("The session is not ending, please ending the session first!");
        current_state="disconnect";
   }else{
       ui->pushButton_9->setStyleSheet("background-color:rgb(255,255,255)");
       ui->pushButton_10->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_11->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_12->setStyleSheet("background-color: rgb(255,255,255)");
   }
}
void MainWindow::up(){
    //wenyueyang change
    if(current_state=="open"||current_state=="choose"){
        current_state="choose";
        ui->pushButton_20->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
        session_color();
        choose_session();
    }else if(current_state=="choose type"){
        ui->pushButton_4->setStyleSheet("background-color:rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        sessiontype_color();
        choose_type();
    }



    //

    int temp_current = stoi(current_selected);
   if (current_state == "session") {

       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = ui->centralwidget->findChild<QLabel*>(buttonName);
       tempPushButton->setStyleSheet(" ");
       if (temp_current < 8){
           temp_current += 1;
       }
       else {
           temp_current = 1;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
   } else if (current_state == "customize") {
 //       int currentTimerCount = 0;
 //       currentTimerCount += 30;
 //       QTime newTime(0,currentTimerCount/60,currentTimerCount%60);
 //       timeString = newTime->toString("mm:ss");
 //       scene->addText(timeString);


 //       QTime newTime = Time->addSecs(60*currentTimerCount);
 //       Time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
 //       ui->countdown->setPlainText(Time->toString("mm:ss"));
       QTime newTime = design_time->addSecs(60*10);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       string str = design_time->toString("mm:ss").toStdString();
       qInfo(design_time->toString("mm:ss").toLatin1());

       }
   current_selected = to_string(temp_current);
     }

 //    //LANYUE
 void MainWindow:: down(){
    //wenyueyang change
     if(current_state=="open"||current_state=="choose"){
         ui->pushButton_20->setStyleSheet("background-color:rgb(255,255,255)");
         ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
         current_state="choose";
         session_color();
         choose_session2();
     }else if(current_state=="choose type"){
         ui->pushButton_4->setStyleSheet("background-color:rgb(255,255,255)");
         ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
         ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
         sessiontype_color();
         choose_type2();
     }

     //



    int temp_current = stoi(current_selected);
   if (current_state == "session") {
       QString buttonName = "push_" + QString::number(temp_current);
       QLabel* tempPushButton = findChild<QLabel*>(buttonName);

           tempPushButton->setStyleSheet(" ");

       if (temp_current > 1){
           temp_current -= 1;
       }
       else {
           temp_current = 8;
       }
       buttonName = "push_" + QString::number(temp_current);
       tempPushButton = findChild<QLabel*>(buttonName);
       if (temp_current >= 7) {
           tempPushButton->setStyleSheet("background-color: rgb(250, 175, 175);");
       }
       else if (temp_current >= 4){
           tempPushButton->setStyleSheet("background-color: yellow");
       }
       else {
           tempPushButton->setStyleSheet("background-color: rgb(138, 226, 52);");
       }
   } else if (current_state == "customize") {
 //       int currentTimerCount = 0;
 //       currentTimerCount += 30;
 //       QTime newTime(0,currentTimerCount/60,currentTimerCount%60);
 //       timeString = newTime->toString("mm:ss");
 //       scene->addText(timeString);


 //       QTime newTime = Time->addSecs(60*currentTimerCount);
 //       Time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
 //       ui->countdown->setPlainText(Time->toString("mm:ss"));
       QTime newTime = design_time->addSecs(-60*10);
       design_time->setHMS(newTime.hour(),newTime.minute(),newTime.second());
       string str = design_time->toString("mm:ss").toStdString();
       qInfo(design_time->toString("mm:ss").toLatin1());
       }
   current_selected = to_string(temp_current);
   }
//yuren
void MainWindow::power(){
    if(current_state=="close"){
        powerOn();
    }else if(current_state=="open"){
        turn_off();
    }else if(current_state==session->getName()){
        //change session group
    }
}
void MainWindow::turn_on(){ //when press power button call this
    if(current_state=="close"){
        QTimer::singleShot(2000, this, &MainWindow::checkTime); //after 2 seconds call checkTime()

    //wenyueYang change
    }else if(current_state=="choose type"){
        current_state="choose";
        current_type=0;
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
    }else if(current_state=="choose"){
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        current_state="open";
    }
}

void MainWindow::checkTime(){ //after 2 seconds, button still being pressed
    if (ui->toolButton->isDown()) { //still in pressed position
        ui->checkBox->setCheckState(Qt::Checked);
        powerOn(); //turn on
    }
}

void MainWindow::powerOn(){
    ui->progressBar->setValue(100);     //set power to 100%
    //what else???
    current_state="open";
}
void MainWindow::turn_off(){
    //Change sessions color to black

    //Change time color to black

    //Change intensity color to black
    ui->push_1->setStyleSheet("color:black");
    ui->push_2->setStyleSheet("color:black");
    ui->push_3->setStyleSheet("color:black");
    ui->push_4->setStyleSheet("color:black");
    ui->push_5->setStyleSheet("color:black");
    ui->push_6->setStyleSheet("color:black");
    ui->push_7->setStyleSheet("color:black");
    ui->push_8->setStyleSheet("color:black");
    //Device power button to unchecked
    ui->checkBox->setChecked(false);
}
//yuren
void MainWindow::change_power(){
    if (current_state == ""){ //doing nothing
        //battery bar does not change
    } else if (current_state == ""){ //doing work
        session->getTime(); //length of therapy
        //Intensity.getlevel(); //intensity ??? use what object ???
        //connections to skin ???
    }
}


//yuan
void MainWindow::stop(){
    if(current_state=="open" || current_state=="in_session"){
       turn_off();
       ui->lineEdit->setText("Session is stooping now!");
    }else{
      ui->lineEdit->setText("Session has benn Stopped!");
    }
}
//yuan
void MainWindow::low_power(){
    if(current_state=="open" && power1->check()==true){
        ui->progressBar->setValue(20);
        ui->lineEdit->setText("Low Power now, Please charge new Battery!");
    }
    if(current_state=="open"&& current_state=="in_session"){
        stop();
        change_power();
        ui->lineEdit->setText("session is running now! Turn off session first!");
    }


//    if(current_session==1 || current_session==2 ||current_session==3){
//        stop();
//        change_power();
//        ui->lineEdit->setText("session is running now! Turn off session first!");
//    }
    //chek battrey level
    //if battrey level <20 mins
    //display 2 bars and blink
    //check current state ="session" warning, replaced battery
}


void MainWindow::selected_button(){
//flash highlighted button
//add a QTimer running 5 seconds
ui->pushButton_1->setStyleSheet("background-color: rgb(255,255,153)");

//wenyueyang
    if(current_state=="choose"){
        cout<<"choose session:"<<current_session+1<<endl;
        if(current_session!=2){
            current_state="choose type";
            sessiontype_color();
        }
    }else if(current_state=="choose type"){
        cout<<"choose session:"<<current_session+1<<endl;
        cout<<"choose type:"<<current_type+1<<endl;
        cout<<"session will start in 5 secounds....."<<endl;
    }
}

void MainWindow::record(){
    //for test
    db->getRecordings(1);
    db->getRecordings(2);
}

void MainWindow::choose_session(){
    current_state="choose";
    if(current_session==0){
       current_session++;
       ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
        current_session++;
      }else{
        current_session=0;
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_session2(){
    current_state="choose";
    if(current_session==0){
       current_session=2;
       ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
        current_session--;
      }else{
        current_session--;
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_type(){
    current_state="choose type";
    if(current_type==0){
       current_type++;
       ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
        current_type++;
      }else if(current_type==2){
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
        current_type++;
      }else{
        current_type=0;
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::choose_type2(){
    current_state="choose type";
    if(current_type==0){
       current_type=2;
       ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,255)");
       ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
     }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
        current_type--;
      }else if(current_type==2){
        current_type--;
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
     }else{
        current_type--;
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,255)");
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
     }
}

void MainWindow::save(){

    db->addProfile(current_user,current_session,current_type,current_intensity);
    qInfo("The personalized Settings are saved successfully");
    db->getProfile(current_user);
}

void  MainWindow::session_color(){
    if(current_session==0){
        ui->pushButton_18->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_session==1){
        ui->pushButton_19->setStyleSheet("background-color: rgb(255,255,153)");
    }else{
        ui->pushButton_20->setStyleSheet("background-color: rgb(255,255,153)");
    }
}

void  MainWindow::sessiontype_color(){
    if(current_type==0){
        ui->pushButton_4->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_type==1){
        ui->pushButton_5->setStyleSheet("background-color: rgb(255,255,153)");
    }else if(current_type==2){
        ui->pushButton_6->setStyleSheet("background-color: rgb(255,255,153)");
    }else{
        ui->pushButton_7->setStyleSheet("background-color: rgb(255,255,153)");
    }
}


void MainWindow::therapy(){
    current_state="in_session";
    therapy_timer=new QTimer();
    therapy_timer->start(Session_group[current_session]->getTime()*1000);
    stop();
    //current_session ==in_session
    // Qtimer  set timer
    //stop();
}


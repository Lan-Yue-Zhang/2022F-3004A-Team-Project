#ifndef RECORDING_H
#define RECORDING_H
using namespace std;
#include <QString>
#include <QSqlDatabase>
#include <QDateTime>
#include <QDebug>
#include <QSqlQuery>
#include <QList>
#include <QApplication>
#include <iostream>
#include <string>

class Recording {

public:
    const QString DATE_FORMAT = "yyyy-MM-dd hh:mm";
    static const QString DATABASE_PATH;

    Recording();
    void getRecordings(int);
    int* getProfile(int);
    void addProfile(int,int,int,int);

private:
    QSqlDatabase db;
    bool Init();

};

#endif


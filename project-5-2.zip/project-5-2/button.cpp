#include"button.h"
BUTTON::BUTTON(){

}

BUTTON::BUTTON(string name){
    this->name=name;
    this->on_off=false;
}
const string& BUTTON::getName(){
    return name;
}
bool BUTTON::getState(){
    return on_off;
}
void BUTTON::switch_on(){
    this->on_off=true;
}
void BUTTON::switch_off(){
    this->on_off=false;
}
void BUTTON::print(){
    printf("this!");
}
